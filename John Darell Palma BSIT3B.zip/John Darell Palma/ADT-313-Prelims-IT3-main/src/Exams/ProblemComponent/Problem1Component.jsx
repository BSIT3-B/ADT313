function Problem1() {
    const user = {
      Studentsname: 'John Darell Palma',
    CourseandYear: 'BSIT-3B',

   
    };
    return (
        <div>
            <p>Studentsname:{user.Studentsname}</p>
            <p>CourseandYear: {user.CourseandYear}</p>
        </div>
    )
}  
export default Problem1;